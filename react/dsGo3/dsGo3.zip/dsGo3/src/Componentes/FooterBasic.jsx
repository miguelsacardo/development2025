export function FooterBasic(){
    return(
        <footer className="text-white font-pixel text-xs flex justify-center p-3">
            &copy; 2025. Todos os Direitos Reservados.
        </footer>
    )
    
}